import aoj

user_id = ['帐号1', '帐号2']
password = ['密码1', '密码2']
sckey = ['sckey1',
         'sckey2']


def main():
    for i in range(len(user_id)):
        aoj.sign(user_id[i], password[i], sckey[i])
